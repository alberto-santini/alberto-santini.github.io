#include "stdafx.h"
#include "basket.h"
#include <ilcplex/ilocplex.h>

// Number of players (p in the text) is n_players
// Number of formations (f in the text) is n_formations
// Number of matches (K in the text) is n_matches
// Which player belongs to which formation (delta[i][j] in the text) is players_in_formation[i][j]
// Number of desired minutes (m[i][k] in the text) is desired_minutes[i][k]
// Plus-minus score of formations (s[j] in the text) is plus_minus_formation[j]
// Plus-minus score of adversaries (S[k] in the text) is plus_minus_adversary[k]

void solve_basket_problem() {
	IloEnv env;

	// Insert yout code here...

	env.end();
}

int main(int argc, char* argv[]) {
	for (std::size_t player = 0; player < 10; ++player) {
		for (std::size_t formation = 0; formation < 15; ++formation) {
			players_in_formations[player][formation] = formations[formation][player];
		}
	}

	solve_basket_problem();
}


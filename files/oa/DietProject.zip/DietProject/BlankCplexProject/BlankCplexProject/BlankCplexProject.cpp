#include "stdafx.h"
#include "diet.h"

#include <ilcplex/ilocplex.h>

int main(int argc, char* argv[]) {
	IloEnv env;
	IloModel model(env);

	// Create variables, obj function, constraints...

	IloCplex cplex(model);

	// Export model, solve, print solution...

	env.end();

	return 0;
}


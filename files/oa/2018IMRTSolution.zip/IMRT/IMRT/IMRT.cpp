#include "imrt.h"
#include <iostream>
#include <ilcplex/ilocplex.h>

int main() {
	IloEnv env;
	IloModel model(env);

	IloNumVarArray x(env, n_configurations, 0, max_intensity_needed, IloNumVar::Int);
	IloNumVarArray y(env, n_configurations, 0, 1, IloNumVar::Bool);

	IloExpr expr(env);

	for (int c = 0; c < n_configurations; ++c) {
		expr += x[c] + switch_time * y[c];
	}
	model.add(IloObjective(env, expr - switch_time, IloObjective::Minimize));
	expr.clear();

	for (int i = 0; i < n_positions_x; ++i) {
		for (int j = 0; j < n_positions_y; ++j) {
			for (int c = 0; c < n_configurations; ++c) {
				expr += areas_covered[c][i][j] * x[c];
			}
			model.add(expr == intensity_needed[i][j]);
			expr.clear();
		}
	}

	for (int c = 0; c < n_configurations; ++c) {
		model.add(x[c] <= big_M * y[c]);
	}

	expr.end();

	IloCplex cplex(model);
	bool solved = false;

	try {
		solved = cplex.solve();
	} catch (...) {
		std::cerr << "Cplex crashed!\n";
		env.end();
		throw;
	}

	if (solved) {
		for (int c = 0; c < n_configurations; ++c) {
			if (cplex.getValue(y[c])) {
				std::cout << "Configuration " << c << " was used for " << cplex.getValue(x[c]) << " minutes\n";
			}
		}
		std::cout << "Total time used: " << cplex.getBestObjValue() << "\n";
	} else {
		std::cerr << "Cplex could not find a solution!\n";
	}

	env.end();
	return 0;
}
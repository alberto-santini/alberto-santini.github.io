#include "diet.h"
#include <iostream>
#include <ilcplex/ilocplex.h>

int main() {
	IloEnv env;
	IloModel model(env);

	IloNumVarArray x(env, n_foods);

	for (int i = 0; i < n_foods; ++i) {
		x[i] = IloNumVar(env, min_foods[i], max_foods[i], IloNumVar::Int);
	}

	IloExpr expr(env);

	for (int i = 0; i < n_foods; ++i) {
		expr += food_costs[i] * x[i];
	}
	model.add(IloObjective(env, expr, IloObjective::Minimize));
	expr.clear();

	for (int j = 0; j < n_nutrients; ++j) {
		for (int i = 0; i < n_foods; ++i) {
			expr += food_nutrients[i][j] * x[i];
		}
		model.add(expr >= min_nutrients[j]);
		model.add(expr <= max_nutrients[j]);
		expr.clear();
	}

	IloCplex cplex(model);
	bool solved = false;

	try {
		solved = cplex.solve();
	} catch (...) {
		std::cerr << "Cplex raised an exception!\n";
		env.end();
		throw;
	}

	if (solved) {
		for (int i = 0; i < n_foods; ++i) {
			std::cout << "We should buy " << cplex.getValue(x[i]) << " units of food " << i << "\n";
		}
		std::cout << "Total cost: " << cplex.getBestObjValue() << "\n";
	} else {
		std::cerr << "Cplex did not find a solution!\n";
	}

	env.end();

	return 0;
}


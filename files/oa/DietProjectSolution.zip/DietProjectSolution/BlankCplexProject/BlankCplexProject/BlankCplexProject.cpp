#include "stdafx.h"
#include "diet.h"
#include <vector>
#include <ilcplex/ilocplex.h>

int main(int argc, char* argv[]) {
	IloEnv env;
	IloModel model(env);

	IloNumVarArray x(env, n_foods);

	IloExpr expr(env);

	for (int i = 0; i < n_foods; ++i) {
		x[i] = IloNumVar(env, min_foods[i], max_foods[i], IloNumVar::Int);
		expr += food_costs[i] * x[i];
	}

	model.add(IloObjective(env, expr, IloObjective::Minimize));
	expr.clear();

	for (int j = 0; j < n_nutrients; ++j) {
		for (int i = 0; i < n_foods; ++i) {
			expr += food_nutrients[i][j] * x[i];
		}
		model.add(IloRange(env, min_nutrients[j], expr, max_nutrients[j]));
		expr.clear();
	}

	expr.end();

	IloCplex cplex(model);

	try {
		if (cplex.solve()) {
			std::vector<int> nutrients_served(n_nutrients, 0);
			for (int i = 0; i < n_foods; ++i) {
				int n_servings = cplex.getValue(x[i]);
				if (n_servings > 0) {
					std::cout << "Buy " << n_servings << " servings of food " << i << std::endl;
					for (int j = 0; j < n_nutrients; ++j) {
						nutrients_served[j] += n_servings * food_nutrients[i][j];
					}
				}
			}
			for (int j = 0; j < n_nutrients; ++j) {
				std::cout << "Total qty of nutrient " << j << ": " << nutrients_served[j] << ", range: [" << min_nutrients[j] << ", " << max_nutrients[j] << "]" << std::endl;
			}
		} else {
			std::cout << "No solution found!" << std::endl;
		}
	} catch (IloException& e) {
		std::cerr << "Cplex exception: " << e.getMessage() << std::endl;
	}

	env.end();

	return 0;
}


#include <array>

int n_foods = 10;
int n_nutrients = 4;

std::array<std::array<int, 4>, 10> food_nutrients = {{
	{ 10, 0, 5, 5 },
	{ 0, 4, 8, 2 },
	{ 4, 4, 6, 4 },
	{ 2, 8, 5, 0 },
	{ 2, 0, 9, 1 },
	{ 0, 0, 3, 12 },
	{ 8, 14, 0, 1 },
	{ 6, 2, 6, 0 },
	{ 2, 6, 11, 3 },
	{ 12, 2, 7, 1 }
}};

std::array<int, 4> min_nutrients = { 12, 12, 20, 16 };
std::array<int, 4> max_nutrients = { 20, 24, 28, 28 };
std::array<int, 10> min_foods = { 0, 1, 0, 0, 0, 1, 0, 0, 1, 0 };
std::array<int, 10> max_foods = { 2, 3, 2, 2, 2, 3, 3, 3, 2, 2 };

int max_food_requirement = 3; // = max(max_foods)

std::array<double, 10> food_costs = { 1.4, 1.4, 1.8, 1.2, 1.0, 0.6, 3.4, 1.6, 1.8, 1.9 };
#include "imrt.h"
#include <iostream>
#include <ilcplex/ilocplex.h>

int main() {
	IloEnv env;
	IloModel model(env);

	// ...

	IloCplex cplex(model);

	// ...

	return 0;
}
#include "diet.h"
#include <ilcplex/ilocplex.h>

int main() {
	IloEnv env;
	IloModel model(env);

	// Create the model.
	// ...

	IloCplex cplex(model);

	// Solve the problem.
	// ...

	// Print the solution.
	// ...

	return 0;
}


#include "stdafx.h"

#include <ilcplex/ilocplex.h>

int main(int argc, char* argv[]) {
	IloEnv env;

	return 0;
}


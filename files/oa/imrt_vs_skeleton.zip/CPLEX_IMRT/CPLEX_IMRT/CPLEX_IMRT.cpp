#include "stdafx.h"
#include "data.h"
#include <ilcplex/ilocplex.h>

void print_solution(const IloModel& model, const IloCplex& cplex, const IloNumVarArray& x) {
	// ...
}

void find_optimal_leaf_sequence() {
	// Data available (see data.h):
	//
	// n_positions_x 					= number of rows in matrix I
	// n_positions_y 					= number of columns in matrix I
	// n_configurations				= number of available configurations for the beam-emitting machine
	// switch_time 						= time to switch configurations
	// intensity_needed[i][j]	= number of minutes position (i,j) needs to be hit with a beam
	// areas_covered[c][i][j]	= 1 if configuration c hits position (i,j) or 0 otherwise
	// max_intensity_needed		= the maximum value of an entry in matrix I
	// big_M 									= a very large number

	IloEnv env;
	IloModel model(env);

	// ...

	env.end();
}

int main() {
	find_optimal_leaf_sequence();
	return 0;
}

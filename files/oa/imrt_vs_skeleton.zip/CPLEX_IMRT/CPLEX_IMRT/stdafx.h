#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>
#include <array>
#include <iostream>
#include <string>
#include <sstream>